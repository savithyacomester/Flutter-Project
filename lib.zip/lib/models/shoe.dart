// models/shoe.dart
class Shoe {
  final String imagePath;
  final String name;
  final String price;

  Shoe({
    required this.imagePath,
    required this.name,
    required this.price,
  });
}
